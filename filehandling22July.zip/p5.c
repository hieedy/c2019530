#include<stdio.h>
int main()
{
	FILE *ptr;
	ptr = fopen("D:\\f1.txt","r");	
	
	if(ptr==NULL)
	{
		printf("File Cannot Opened. ");
	}
	else
	{
		char ch;
		ch = fgetc(ptr);
		
		while(ch!=EOF)
		{
				printf("%c",ch);
					ch = fgetc(ptr);
		}
	
	}
	
	fclose(ptr);

}


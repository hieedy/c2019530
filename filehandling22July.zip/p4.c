#include<stdio.h>
int main()
{
	FILE *ptr;
	ptr = fopen("D:\\f1.txt","w");	
	
	if(ptr==NULL)
	{
		printf("File Cannot Opened. ");
	}
	else
	{
		char ch;
		printf("enter  ~ to exit");
		scanf("%c",&ch);
		while(ch!='~')
		{
			fputc(ch,ptr);
			scanf("%c",&ch);	
		}
		printf("Data written Succesfully........");
	}
	
	fclose(ptr);

}


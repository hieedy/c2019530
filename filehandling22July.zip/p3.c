#include<stdio.h>
int main()
{
	FILE *ptr;
	ptr = fopen("D:\\f1.txt","w");	
	
	if(ptr==NULL)
	{
		printf("File Cannot Opened. ");
	}
	else
	{
		char ch='H';
		fputc(ch,ptr);
		printf("Data written Succesfully........");
	}
	
	fclose(ptr);

}


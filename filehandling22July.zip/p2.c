#include<stdio.h>
int main()
{
	FILE *ptr;
	ptr = fopen("D:\\f1.txt","w");	
	
	if(ptr==NULL)
	{
		printf("File Cannot Opened. ");
	}
	else{
		printf("File Opened Successfully");
	}
	
	fclose(ptr);


}


//declare a file pointer
//open a file
//read/write content
//close a file

#include<stdio.h>
int main()
{
		FILE *ptr;
	ptr = fopen("D:\\f1.txt","r");	
	
	if(ptr==NULL)
	{
		printf("File Cannot Opened. ");
	}
	else
	{
		int count=0;
		char ch = fgetc(ptr);
		while(ch!=EOF)
		{
			count++;
			ch = fgetc(ptr);
		}
		
		printf("file is of %d bytes",count);
		fclose(ptr);
	}
}

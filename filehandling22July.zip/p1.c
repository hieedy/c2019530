#include<stdio.h>
struct student
{
	int age;
}s1;
int main()
{
	struct student *ptr;
	
	ptr = &s1;
	
	ptr->age=20;
	
	printf("%d",ptr->age);
}
